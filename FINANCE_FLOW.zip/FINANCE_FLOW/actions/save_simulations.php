<?php
// Enable detailed error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Logging function for debugging
function debug_log($message) {
    file_put_contents('debug_log.txt', date('[Y-m-d H:i:s] ') . $message . "\n", FILE_APPEND);
}

// Start session and include configuration
session_start();

$config_file = '../db/config.php';
if (file_exists($config_file)) {
    include $config_file;
} else {
    debug_log("Database configuration file missing");
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'System configuration error. Please contact support.'
    ]);
    exit;
}

// Validate and process POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Log incoming data for debugging
    debug_log("Received POST data: " . print_r($_POST, true));
    debug_log("Received FILES data: " . print_r($_FILES, true));

    // Validate inputs from form data
    $initialInvestment = filter_input(INPUT_POST, 'initialInvestment', FILTER_VALIDATE_FLOAT);
    $period = filter_input(INPUT_POST, 'period', FILTER_VALIDATE_INT);
    $monthlyContribution = filter_input(INPUT_POST, 'monthlyContribution', FILTER_VALIDATE_FLOAT);
    $riskTolerance = filter_input(INPUT_POST, 'riskTolerance', FILTER_SANITIZE_STRING);
    $selectedAssets = isset($_POST['selectedAssets']) ? $_POST['selectedAssets'] : [];
    $expectedReturns = filter_input(INPUT_POST, 'expectedReturns', FILTER_VALIDATE_FLOAT);

    // Perform comprehensive input validation
    $validationErrors = [];

    if ($initialInvestment === false || $initialInvestment < 100) {
        $validationErrors[] = 'Invalid initial investment. Must be at least $100.';
    }

    if ($period === false || $period < 1 || $period > 30) {
        $validationErrors[] = 'Invalid investment period. Must be between 1 and 30 years.';
    }

    if ($monthlyContribution === false || $monthlyContribution < 0) {
        $validationErrors[] = 'Invalid monthly contribution. Must be non-negative.';
    }

    if (empty($riskTolerance)) {
        $validationErrors[] = 'Risk tolerance is required.';
    }

    if (empty($selectedAssets)) {
        $validationErrors[] = 'At least one asset must be selected.';
    }

    if ($expectedReturns === false) {
        $validationErrors[] = 'Invalid expected returns.';
    }

    // Check if user is logged in
    if (!isset($_SESSION['user_id'])) {
        $validationErrors[] = 'User not logged in.';
    }

    // If there are validation errors, return them
    if (!empty($validationErrors)) {
        http_response_code(400);
        echo json_encode([
            'status' => 'error',
            'message' => 'Validation failed',
            'errors' => $validationErrors
        ]);
        exit;
    }

    // Prepare database insertion
    try {
        // Check if connection exists
        if (!$conn) {
            throw new Exception('Database connection not established');
        }

        // Begin transaction for robust database operation
        mysqli_begin_transaction($conn);

        // Convert selected assets to a comma-separated string
        $assetsString = is_array($selectedAssets) ? implode(',', $selectedAssets) : $selectedAssets;

        // Escape inputs to prevent SQL injection
        $userId = intval($_SESSION['user_id']);
        $initialInvestment = mysqli_real_escape_string($conn, $initialInvestment);
        $period = mysqli_real_escape_string($conn, $period);
        $monthlyContribution = mysqli_real_escape_string($conn, $monthlyContribution);
        $riskTolerance = mysqli_real_escape_string($conn, $riskTolerance);
        $assetsString = mysqli_real_escape_string($conn, $assetsString);
        $expectedReturns = mysqli_real_escape_string($conn, $expectedReturns);

        // Prepare and execute the insert statement
        $query = "INSERT INTO investment_simulations 
            (user_id, investment_amount, investment_period, monthly_contributions, 
            risk, asset_name, return_amount, simulation_date) 
            VALUES ('$userId', '$initialInvestment', '$period', '$monthlyContribution', 
            '$riskTolerance', '$assetsString', '$expectedReturns', NOW())";
        
        // Execute query
        $result = mysqli_query($conn, $query);

        if (!$result) {
            throw new Exception('Failed to execute query: ' . mysqli_error($conn));
        }

        // Commit the transaction
        mysqli_commit($conn);

        // Return success response
        // echo json_encode([
        //     'status' => 'success',
        //     'message' => 'Simulation data saved successfully'
        // ]);

        $_SESSION['simulation_status'] = [
            'status' => 'success',
            'message' => 'Simulation data saved successfully'
        ];
        header('Location: ../view/investmentSimulator.php');
        exit;

    } catch (Exception $e) {
        // Rollback transaction in case of error
        mysqli_rollback($conn);

        // Log the error
        debug_log("Database error: " . $e->getMessage());

        // Return error response
        http_response_code(500);
        echo json_encode([
            'status' => 'error',
            'message' => 'Error saving simulation: ' . $e->getMessage()
        ]);

        $_SESSION['simulation_status'] = [
            'status' => 'error',
            'message' => 'Failed to save simulation: ' . $e->getMessage()
        ];
        header('Location: ../view/investmentSimulator.php');
        exit;
    }
} else {
    // Method not allowed
    http_response_code(405);
    echo json_encode([
        'status' => 'error',
        'message' => 'Method Not Allowed'
    ]);
    exit;
}
?>