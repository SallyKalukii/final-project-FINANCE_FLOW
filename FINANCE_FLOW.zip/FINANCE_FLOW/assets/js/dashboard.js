// Mobile menu toggle
function toggleMenu() {
    const navLinks = document.querySelector('.nav-links');
    navLinks.classList.toggle('active');
}

// Sample dashboard interactions
function viewDetails(section) {
    const sections = {
        'spending': 'Spending Analysis',
        'investment': 'Investment Portfolio',
        'learning': 'Learning Modules'
    };
    
    alert(`Navigating to ${sections[section]}...`);
}

// Simulate real-time updates
setInterval(() => {
    const metrics = document.querySelectorAll('.metric p');
    metrics.forEach(metric => {
        if (metric.textContent.includes('$')) {
            const currentValue = parseFloat(metric.textContent.replace('$', '').replace(',', ''));
            const newValue = currentValue + (Math.random() - 0.5) * 10;
            metric.textContent = `$${newValue.toFixed(2)}`;
        }
    });
}, 5000);

// Add notification system
document.querySelector('.notification-badge').addEventListener('click', () => {
    alert('Loading notifications...');
});
