document.addEventListener('DOMContentLoaded', () => {
    const goalForm = document.getElementById('goalForm');
    const updateProgressForm = document.getElementById('updateProgressForm');

    // Create Goal Form Submit
    goalForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const goalName = document.getElementById('goalName').value;
        const goalAmount = document.getElementById('goalAmount').value;
        const goalDate = document.getElementById('goalDate').value;
        const goalCategory = document.getElementById('goalCategory').value;

        const formData = new FormData();
        formData.append('action', 'create_goal');
        formData.append('goal_name', goalName);
        formData.append('target_amount', goalAmount);
        formData.append('target_date', goalDate);
        formData.append('category', goalCategory);

        fetch(window.location.href, {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                closeGoalModal();
                location.reload(); // Reload to show new goal
            } else {
                alert(data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while creating the goal.');
        });
    });

    // Update Progress Form Submit
    updateProgressForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const goalId = document.getElementById('updateGoalId').value;
        const savedAmount = document.getElementById('savedAmount').value;

        const formData = new FormData();
        formData.append('action', 'update_progress');
        formData.append('goal_id', goalId);
        formData.append('saved_amount', savedAmount);

        fetch(window.location.href, {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                closeUpdateProgressModal();
                location.reload(); // Reload to show updated progress
            } else {
                alert(data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while updating progress.');
        });
    });
});

// Modal functions
function openGoalModal() {
    document.getElementById('goalModal').style.display = 'block';
}

function closeGoalModal() {
    document.getElementById('goalModal').style.display = 'none';
    document.getElementById('goalForm').reset();
}

function openUpdateProgressModal(goalId, targetAmount, currentSaved) {
    const savedAmountInput = document.getElementById('savedAmount');
    const updateGoalIdInput = document.getElementById('updateGoalId');

    updateGoalIdInput.value = goalId;
    savedAmountInput.value = currentSaved;
    savedAmountInput.max = targetAmount;

    document.getElementById('updateProgressModal').style.display = 'block';
}

function closeUpdateProgressModal() {
    document.getElementById('updateProgressModal').style.display = 'none';
    document.getElementById('updateProgressForm').reset();
}

// Optional: Celebrate function for achieving goals
function celebrate() {
    const celebrateElement = document.getElementById('celebrate');
    celebrateElement.style.display = 'block';
    setTimeout(() => {
        celebrateElement.style.display = 'none';
    }, 3000);
}

function deleteAchievement(goalId) {
    if (confirm('Are you sure you want to delete this achievement?')) {
        fetch('goalTracking.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `action=delete_achievement&goal_id=${goalId}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Remove the achievement card from the DOM
                const achievementCard = document.querySelector(`.achievement-card[data-goal-id="${goalId}"]`);
                if (achievementCard) {
                    achievementCard.remove();
                }
                // Reload the page to update the achievements list
                location.reload();
            } else {
                alert('Failed to delete achievement');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while deleting the achievement');
        });
    }
}