let chart;
const assetCards = document.querySelectorAll('.asset-card');
let selectedAssets = new Set();

assetCards.forEach(card => {
    card.addEventListener('click', () => {
        card.classList.toggle('selected');
        const asset = card.dataset.asset;
        if (selectedAssets.has(asset)) {
            selectedAssets.delete(asset);
        } else {
            selectedAssets.add(asset);
        }
    });
});

function getAssetReturns(asset, riskTolerance) {
    const baseReturns = {
        stocks: { conservative: 6, moderate: 8, aggressive: 10 },
        bonds: { conservative: 3, moderate: 4, aggressive: 5 },
        mutualFunds: { conservative: 5, moderate: 7, aggressive: 9 },
        crypto: { conservative: 10, moderate: 15, aggressive: 20 }
    };

    return baseReturns[asset][riskTolerance];
}

function calculateInvestment() {
    const initialInvestment = parseFloat(document.getElementById('initialInvestment').value);
    const period = parseInt(document.getElementById('period').value);
    const monthlyContribution = parseFloat(document.getElementById('monthlyContribution').value);
    const riskTolerance = document.getElementById('riskTolerance').value;

    if (selectedAssets.size === 0) {
        alert('Please select at least one asset type');
        return;
    }

    let averageReturn = 0;
    selectedAssets.forEach(asset => {
        averageReturn += getAssetReturns(asset, riskTolerance);
    });
    averageReturn /= selectedAssets.size;

    const monthlyRate = averageReturn / 100 / 12;
    const months = period * 12;
    
    const projectedValues = [];
    let currentValue = initialInvestment;

    for (let i = 0; i <= months; i++) {
        projectedValues.push({
            month: i,
            value: currentValue
        });
        currentValue = currentValue * (1 + monthlyRate) + monthlyContribution;
    }

    const totalContributed = initialInvestment + (monthlyContribution * months);
    const finalValue = projectedValues[projectedValues.length - 1].value;

    document.getElementById('totalInvestment').textContent = 
        `$${totalContributed.toFixed(2)}`;
    document.getElementById('expectedReturns').textContent = 
        `$${(finalValue - totalContributed).toFixed(2)}`;
    document.getElementById('riskLevel').textContent = 
        `${averageReturn.toFixed(1)}%`;

    updateChart(projectedValues);
}

function updateChart(data) {
    const ctx = document.getElementById('investmentChart').getContext('2d');
    
    if (chart) {
        chart.destroy();
    }

    chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.map(d => `Year ${Math.floor(d.month / 12)}`),
            datasets: [{
                label: 'Portfolio Value',
                data: data.map(d => d.value),
                borderColor: '#2563eb',
                backgroundColor: 'rgba(37, 99, 235, 0.1)',
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: value => `$${value.toLocaleString()}`
                    }
                }
            }
        }
    });
}

// Initialize with default values
calculateInvestment();
