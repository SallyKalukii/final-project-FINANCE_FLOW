function startModule(moduleName) {
    // Add your module navigation logic here
    console.log(`Starting ${moduleName} module`);
    // This would typically navigate to the specific module content
    alert(`Loading ${moduleName} module...`);
}
function showContent(content) {
    console.log("Raw content:", content); // Debug log
    
    try {
        const contentDiv = document.getElementById('moduleContent');
        
        if (!contentDiv) {
            console.error("Content div not found!");
            return;
        }
        
        if (!content) {
            contentDiv.innerHTML = "No content available.";
            console.warn("Empty content received");
            return;
        }
        
        // Decode HTML entities and set innerHTML
        contentDiv.innerHTML = content;
        
        console.log("Content successfully displayed");
    } catch (error) {
        console.error('Error displaying content:', error);
        alert('Unable to load module content');
    }
}
