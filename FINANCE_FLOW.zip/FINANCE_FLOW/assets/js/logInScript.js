document.getElementById('login-form').addEventListener('submit', function(e) {
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();
    let isValid = true;
    let errorMessage = '';

    if (!email) {
        errorMessage += 'Email is required.\n';
        isValid = false;
    } else if (!/\S+@\S+\.\S+/.test(email)) {
        errorMessage += 'Please enter a valid email address.\n';
        isValid = false;
    }

    if (!password) {
        errorMessage += 'Password is required.\n';
        isValid = false;
    }

    if (!isValid) {
        e.preventDefault();
        alert(errorMessage);
    }
});