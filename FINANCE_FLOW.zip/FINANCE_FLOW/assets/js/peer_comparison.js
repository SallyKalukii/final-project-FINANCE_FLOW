// Retrieve user data and platform averages/medians from an API or database
// For now, using sample data
const userMetrics = {
    savingsRate: 15.2,
    budgetAdherence: 82,
    investmentAllocation: {
        stocks: 70,
        bonds: 30
    },
    debtToIncome: 28,
    emergencyFund: 8200,
    creditScore: 780,
    retirementContributions: 12,
    netWorthGrowth: 8.2,
    charitableGiving: 3.1
};

const platformMetrics = {
    savingsRate: 12.7,
    budgetAdherence: 75,
    investmentAllocation: {
        stocks: 60,
        bonds: 40
    },
    debtToIncome: 35,
    emergencyFund: 6500,
    creditScore: 725,
    retirementContributions: 10,
    netWorthGrowth: 6.5,
    charitableGiving: 2.4
};

document.addEventListener('DOMContentLoaded', () => {
    updatePeerComparisonData();
});

function updatePeerComparisonData() {
    document.getElementById('savingsRate').textContent = `${userMetrics.savingsRate}%`;
    document.getElementById('budgetAdherence').textContent = `${userMetrics.budgetAdherence}%`;
    document.getElementById('investmentAllocation').textContent = `${userMetrics.investmentAllocation.stocks}% stocks, ${userMetrics.investmentAllocation.bonds}% bonds`;
    document.getElementById('debtToIncome').textContent = `${userMetrics.debtToIncome}%`;
    document.getElementById('emergencyFund').textContent = `$${userMetrics.emergencyFund.toLocaleString()}`;
    document.getElementById('creditScore').textContent = userMetrics.creditScore;
    document.getElementById('retirementContributions').textContent = `${userMetrics.retirementContributions}% of income`;
    document.getElementById('netWorthGrowth').textContent = `${userMetrics.netWorthGrowth}% YoY`;
    document.getElementById('charitableGiving').textContent = `${userMetrics.charitableGiving}% of income`;
}

document.getElementById('privacy-checkbox').addEventListener('change', (e) => {
    // Toggle visibility of user data based on privacy settings
    if (e.target.checked) {
        // Hide user data
        document.querySelectorAll('.metric-card p').forEach(p => p.textContent = 'Hidden');
        document.querySelectorAll('.metric-card span').forEach(span => span.textContent = 'Platform Average');
    } else {
        // Show user data
        updatePeerComparisonData();
    }
});
