// Sample data for different time periods
const timePeriodsData = {
    month: {
        spending: [850, 400, 300, 200, 250, 300, 150],
        trend: {
            labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
            data: [500, 600, 450, 700]
        }
    },
    quarter: {
        spending: [2500, 1200, 900, 600, 750, 900, 450],
        trend: {
            labels: ['Month 1', 'Month 2', 'Month 3'],
            data: [1500, 1800, 1350]
        }
    },
    halfYear: {
        spending: [5000, 2400, 1800, 1200, 1500, 1800, 900],
        trend: {
            labels: ['Month 1', 'Month 2', 'Month 3', 'Month 4', 'Month 5', 'Month 6'],
            data: [2500, 2800, 2350, 2700, 2400, 2600]
        }
    },
    year: {
        spending: [10000, 4800, 3600, 2400, 3000, 3600, 1800],
        trend: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            data: [2500, 2800, 2350, 2700, 2400, 2600, 2800, 2900, 2700, 2500, 2400, 2300]
        }
    }
};

let spendingChart, trendChart;

// Initialize charts
function initializeCharts() {
    const spendingCtx = document.getElementById('spendingChart').getContext('2d');
    const trendCtx = document.getElementById('trendChart').getContext('2d');

    // Spending breakdown chart
    spendingChart = new Chart(spendingCtx, {
        type: 'doughnut',
        data: {
            labels: ['Housing', 'Food', 'Transportation', 'Utilities', 'Entertainment', 'Shopping', 'Others'],
            datasets: [{
                data: timePeriodsData.month.spending,
                backgroundColor: [
                    '#800020', '#aa1835', '#c41e3a', '#dc143c',
                    '#e34234', '#ff2400', '#ff4040'
                ]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });

    // Trend chart
    trendChart = new Chart(trendCtx, {
        type: 'line',
        data: {
            labels: timePeriodsData.month.trend.labels,
            datasets: [{
                label: 'Total Spending',
                data: timePeriodsData.month.trend.data,
                borderColor: '#800020',
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

// Update charts based on selected time period
function updateCharts(period) {
    spendingChart.data.datasets[0].data = timePeriodsData[period].spending;
    spendingChart.update();

    trendChart.data.labels = timePeriodsData[period].trend.labels;
    trendChart.data.datasets[0].data = timePeriodsData[period].trend.data;
    trendChart.update();
}

// Handle filter button clicks
document.querySelectorAll('.filter-btn[data-period]').forEach(button => {
    button.addEventListener('click', (e) => {
        // Update active state
        document.querySelectorAll('.filter-btn').forEach(btn => btn.classList.remove('active'));
        e.target.classList.add('active');

        // Update charts
        updateCharts(e.target.dataset.period);
    });
});

// Handle custom date range
function applyCustomRange() {
    const startDate = document.getElementById('startDate').value;
    const endDate = document.getElementById('endDate').value;
    
    if (startDate && endDate) {
        // Here you would typically fetch data for the custom range
        // For demo, we'll just use the quarterly data
        updateCharts('quarter');
        
        // Remove active state from other buttons
        document.querySelectorAll('.filter-btn[data-period]').forEach(btn => {
            btn.classList.remove('active');
        });
    }
}

// Initialize charts on load
document.addEventListener('DOMContentLoaded', () => {
    initializeCharts();
    
    // Set default dates for custom range
    const today = new Date();
    const lastMonth = new Date(today.getFullYear(), today.getMonth() - 1, today.getDate());
    
    document.getElementById('startDate').value = lastMonth.toISOString().split('T')[0];
    document.getElementById('endDate').value = today.toISOString().split('T')[0];
});
