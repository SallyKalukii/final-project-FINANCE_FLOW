<?php
$servername = 'localhost';
$username = "salome.mutemwa";
$password = "Zirr@the2ebra";
$dbname = "webtech_fall2024_salome_mutemwa";

// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL); 

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) 
{
  die("Connection failed: " . mysqli_connect_error());
}  
else{
//   echo "Connected successfully";
}
?>

