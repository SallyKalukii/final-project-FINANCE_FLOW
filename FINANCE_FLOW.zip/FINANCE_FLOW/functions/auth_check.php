<?php
// File: ../functions/auth_check.php

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Function to redirect to login page
function redirectToLogin() {
    header("Location: ../view/login.php");
    exit();
}

// Check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']) && isset($_SESSION['email']);
}

// Authentication check for protected pages
function authCheck() {
    if (!isLoggedIn()) {
        // Set a message to show after login
        $_SESSION['redirect_message'] = "Please log in to access this page.";
        redirectToLogin();
    }
}

// Optional: Role-based access control
function checkUserRole($required_roles = []) {
    // If no roles specified, just check if logged in
    if (empty($required_roles)) {
        authCheck();
        return true;
    }

    // Check if user has the required role
    if (!isLoggedIn() || !isset($_SESSION['role'])) {
        redirectToLogin();
    }

    if (!in_array($_SESSION['role'], $required_roles)) {
        // Redirect to unauthorized access page or show error
        //header("Location: ../errors/unauthorized.php");
        exit();
    }

    return true;
}

// Login function
function loginUser($user_id, $fname, $lname, $email, $role = 'user') {
    $_SESSION['user_id'] = $user_id;
    $_SESSION['fname'] = $fname;
    $_SESSION['lname'] = $lname;
    $_SESSION['role'] = $role;
    $_SESSION['last_activity'] = time();
}

// Logout function
function logoutUser() {
    // Unset all session variables
    $_SESSION = [];

    // Destroy the session
    session_destroy();

    // Redirect to login page
    header("Location: ../view/login.php");
    exit();
}

// Optional: Session timeout check
function checkSessionTimeout($max_lifetime = 3600) { // 1 hour
    if (isset($_SESSION['last_activity'])) {
        $inactive = time() - $_SESSION['last_activity'];
        if ($inactive > $max_lifetime) {
            logoutUser();
        }
    }
}

// Call this at the top of protected pages
authCheck();
// Optional: Call this to check session timeout
// checkSessionTimeout();
?>