<?php 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FinanceFlow - Interactive Financial Education Platform</title>
    <!-- Link to external CSS -->
    <style>
        <?php include 'assets/css/index.css';?>
    </style>
</head>
<body> 
    <nav class="navbar">
        <div class="logo">FinanceFlow</div>
        <div class="nav-links">
            <a href="#features">Features</a>
            <a href="view/login.php">Login</a>
            <a href="view/register.php" class="cta">Register</a>
        </div>
    </nav>

    <section class="hero">
        <h1>Master Your Finances</h1>
        <p>Join FinanceFlow to develop healthy financial habits through real-world data analysis, interactive simulations, and personalized learning paths.</p>
        <a href="view/register.php" class="hero-button">Start Your Journey</a>
    </section>

    <!-- Rest of the sections remain the same -->
    <section class="features" id="features">
        <h2 class="section-title">Why Choose FinanceFlow?</h2>
        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon">📊</div>
                <h3>Spending Pattern Analysis</h3>
                <p>Gain insights into your spending habits with advanced analytics and personalized recommendations.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">📈</div>
                <h3>Investment Simulation</h3>
                <p>Practice investment strategies in a risk-free environment with real-world market data.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">🎯</div>
                <h3>Goal Tracking</h3>
                <p>Set financial goals and track your progress with detailed metrics and achievements.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">👥</div>
                <h3>Learning Center</h3>
                <p>Take financial modules and learn more about bugdeting, investment simulation and any other financial module.</p>
            </div>
        </div>
    </section>

    <section class="contact" id="contact">
        <h2 class="section-title">Contact Us</h2>
        <div class="contact-content">
            <div class="contact-info">
                <div class="contact-card">
                    <a href="https://instagram.com/salsmuzzey_" target="_blank" class="contact-link">
                        <i class="fab fa-instagram"></i>
                        <h3>Instagram</h3>
                        <p>@salsmuzzey_</p>
                    </a>
                    <a href="mailto:sallymutemwa@gmail.com" class="contact-link">
                        <i class="fas fa-envelope"></i>
                        <h3>Email</h3>
                        <p>sallymutemwa@gmail.com</p>
                    </a>
                    <a href="tel:+233544004631" class="contact-link">
                        <i class="fas fa-phone"></i>
                        <h3>Phone</h3>
                        <p>+233 544 004 631</p>
                    </a>
                </div>
                <div class="quote-section">
                    <p class="quote">"Financial freedom is about more than just having money. It's about the freedom to be who you really are and do what you really want in life."</p>
                    <p class="quote-author">- Robert Kiyosaki</p>
                </div>
            </div>
        </div>
    </section>
</body>
</html>