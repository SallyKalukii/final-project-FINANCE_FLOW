<?php
session_start();

// Load the database configuration file
$config_file = '../db/config.php';
if (file_exists($config_file)) {
    include $config_file;
} else {
    error_log("Database configuration file missing");
    echo json_encode(['success' => false, 'message' => 'Database configuration error']);
    exit;
}

// Check if the POST data contains 'id'
if (!isset($_POST['id'])) {
    error_log("Module ID not provided in POST request");
    echo json_encode(['success' => false, 'message' => 'No module ID provided']);
    exit;
}

$moduleId = intval($_POST['id']);

// Update the progress in the database
$sql = "UPDATE learning_modules SET progress = 100 WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $moduleId);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Progress updated']);
} else {
    error_log("Database update failed: " . $stmt->error);
    echo json_encode(['success' => false, 'message' => 'Database update failed']);
}

$stmt->close();
$conn->close();
?>
