<?php
require_once '../../db/config.php';
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

// Get user information
$user_query = "SELECT fname, lname FROM finance_users WHERE user_id = ?";
$stmt = $conn->prepare($user_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user_result = $stmt->get_result();
$user_data = $user_result->fetch_assoc();

// For normal users: Get spending patterns
$spending_query = "SELECT COALESCE(SUM(amount), 0) as total_spending 
                  FROM spending_patterns 
                  WHERE user_id = ? 
                  AND MONTH(transaction_date) = MONTH(CURRENT_DATE())";

$stmt = $conn->prepare($spending_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$spending_result = $stmt->get_result();
$spending_data = $spending_result->fetch_assoc();

// Get investment data
$investment_query = "SELECT 
                    COALESCE(SUM(investment_amount), 0) as total_investment, 
                    COALESCE(AVG(return_rate), 0) as avg_return 
                    FROM investment_simulations 
                    WHERE user_id = ?";
                    
$stmt = $conn->prepare($investment_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$investment_result = $stmt->get_result();
$investment_data = $investment_result->fetch_assoc();

// Get user's learning progress
$learning_query = "SELECT 
    m.module_name,
    COALESCE(ump.progress, 0) as progress
FROM learning_modules m
LEFT JOIN user_module_progress ump ON m.id = ump.module_id 
    AND ump.user_id = ?
ORDER BY m.id
LIMIT 1";  // Get the current module

$stmt = $conn->prepare($learning_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$learning_result = $stmt->get_result();
$learning_data = $learning_result->fetch_assoc();

// If no modules are found, set default values
if (!$learning_data) {
    $learning_data = [
        'module_name' => 'No modules available',
        'progress' => 0
    ];
}
// For admins: Get system-wide statistics
if ($role <= 2) { // Super admin or regular admin
    $total_users = $conn->query("SELECT COUNT(*) as count FROM finance_users")->fetch_assoc()['count'];
    $total_modules = $conn->query("SELECT COUNT(*) as count FROM learning_modules")->fetch_assoc()['count'];
    $total_investments = $conn->query("SELECT COUNT(*) as count FROM investment_simulations")->fetch_assoc()['count'];
}

// Fetch user's achievements from financial_goals
$achievements_query = "SELECT * FROM financial_goals 
                      WHERE user_id = ? 
                      AND status = 'Achieved' 
                      ORDER BY target_date DESC 
                      LIMIT 5";
$stmt = $conn->prepare($achievements_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$achievements_result = $stmt->get_result();
$achievements = [];
while ($row = $achievements_result->fetch_assoc()) {
    $achievements[] = $row;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FinanceFlow Dashboard</title>
    <!-- <link rel="stylesheet" href="../../assets/css/dashboard.css"> -->
    <style>
        <?php include "../../assets/css/dashboard.css";?>
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar">
        <div class="nav-container">
            <a href="#" class="logo">FinanceFlow</a>
            
            <div class="menu-toggle" onclick="toggleMenu()">
                <span></span>
                <span></span>
                <span></span>
            </div>

            <div class="nav-links">
                <a href="#" class="active">Dashboard</a>
                <a href="../../view/services.php">Back to Services</a>
                <a href="../../view/profile.php">Edit Profile</a>
                
            </div>

        </div>
    </nav>

    <div class="dashboard">
        <div class="header">
            <div>
                <h1>Welcome back, <?php echo htmlspecialchars($user_data['fname']); ?>!</h1>
                <p>Your financial journey continues</p>
            </div>
            <div class="notification-badge">3 New Updates</div>
        </div>

        <?php if ($role <= 2): // Admin Dashboard ?>
        <div class="grid-container">
            <div class="card">
                <h3>System Overview</h3>
                <div class="metrics">
                    <div class="metric">
                        <h4>Total Users</h4>
                        <p><?php echo $total_users; ?></p>
                    </div>
                    <div class="metric">
                        <h4>Learning Modules</h4>
                        <p><?php echo $total_modules; ?></p>
                    </div>
                </div>
                <button class="btn" onclick="location.href='../modulesManagement.php'">Manage Modules</button>
            </div>

            <div class="card">
                <h3>Platform Statistics</h3>
                <div class="metrics">
                    <div class="metric">
                        <h4>Total Investments</h4>
                        <p><?php echo $total_investments; ?></p>
                    </div>
                    <div class="metric">
                        <h4>Active Users</h4>
                        <p><?php echo $total_users; ?></p>
                    </div>
                </div>
            </div>
            <!-- Add more admin-specific cards -->
        </div>

        <?php else: // Normal User Dashboard ?>
        <div class="grid-container">
            <div class="card">
                <h3>Spending Pattern</h3>
                <div class="metrics">
                    <div class="metric">
                        <h4>Monthly Spending</h4>
                        <p>$<?php echo number_format($spending_data['total_spending'] ?? 0, 2); ?></p>
                    </div>
                </div>
                <button class="btn" onclick="window.location.href='../../view/spendingAnalysis.php'">View Details</button>
            </div>

            <div class="card">
                <h3>Investment Portfolio</h3>
                <div class="metrics">
                    <div class="metric">
                        <h4>Total Value</h4>
                        <p>$<?php echo number_format($investment_data['total_investment'] ?? 0, 2); ?></p>
                    </div>
                    <div class="metric">
                        <h4>Return Rate</h4>
                        <p><?php echo number_format($investment_data['avg_return'] ?? 0, 1); ?>%</p>
                    </div>
                </div>
                <button class="btn" onclick="window.location.href='../../view/investmentSimulator.php'">View Details</button>
            </div>

            <div class="card">
                <h3>Learning Progress</h3>
                <p>Current Module: <?php echo htmlspecialchars($learning_data['module_name']); ?></p>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: <?php echo $learning_data['progress']; ?>%"></div>
                </div>
                <p><?php echo number_format($learning_data['progress'], 0); ?>% Complete</p>
                <button class="btn" onclick="window.location.href='../../view/learningCenter.php'">View Details</button>
            </div>
        </div>
        <?php endif; ?>

        <div class="card achievements-card">
            <h3>Recent Achievements</h3>
            <?php if (count($achievements) > 0): ?>
                <?php foreach ($achievements as $achievement): ?>
                    <div class="achievement">
                        <?php
                        // Set achievement icon based on category
                        $icon = match($achievement['category']) {
                            'Savings' => '💰',
                            'Investment' => '📈',
                            'Debt Repayment' => '✅',
                            'Emergency Fund' => '🎯',
                            default => '🌟'
                        };
                        ?>
                        <div class="achievement-icon"><?php echo $icon; ?></div>
                        <div>
                            <h4><?php echo htmlspecialchars($achievement['goal_name']); ?></h4>
                            <p>Achieved $<?php echo number_format($achievement['target_amount'], 2); ?> 
                            in <?php echo htmlspecialchars($achievement['category']); ?></p>
                            <small>Completed on <?php echo date('M d, Y', strtotime($achievement['target_date'])); ?></small>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="achievement">
                    <div class="achievement-icon">🎯</div>
                    <div>
                        <h4>Set Your First Goal!</h4>
                        <p>Start your financial journey by creating a goal</p>
                    </div>
                </div>
            <?php endif; ?>
            
            <button class="btn" onclick="location.href='../goalTracking.php'">View All Goals</button>
        </div>
    </div>

    <script src="../../assets/js/dashboard.js"></script>
</body>
</html>