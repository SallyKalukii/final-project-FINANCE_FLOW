<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once '../db/config.php';
require_once '../functions/auth_check.php'; 


// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../view/login.php');
    exit();
}


$user_id = $_SESSION['user_id'];

// Handle goal creation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create_goal') {
    $goal_name = $conn->real_escape_string($_POST['goal_name']);
    $target_amount = $conn->real_escape_string($_POST['target_amount']);
    $target_date = $conn->real_escape_string($_POST['target_date']);
    $category = $conn->real_escape_string($_POST['category']);

    // Additional input validation
    if (empty($goal_name) || $target_amount <= 0 || empty($target_date)) {
        throw new Exception("Invalid input data");
    }
    
    $sql = "INSERT INTO financial_goals (user_id, goal_name, target_amount, target_date, category) 
            VALUES ('$user_id', '$goal_name', '$target_amount', '$target_date', '$category')";
    
    if ($conn->query($sql)) {
        echo json_encode(['success' => true, 'message' => 'Goal created successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to create goal']);
    }
    exit();
}

// Handle goal progress update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_progress') {
    $goal_id = $conn->real_escape_string($_POST['goal_id']);
    $saved_amount = $conn->real_escape_string($_POST['saved_amount']);

    $sql = "UPDATE financial_goals 
            SET saved_amount = '$saved_amount', 
                status = CASE 
                    WHEN saved_amount >= target_amount THEN 'Achieved' 
                    ELSE 'In Progress' 
                END 
            WHERE id = '$goal_id' AND user_id = '$user_id'";
    
    if ($conn->query($sql)) {
        echo json_encode(['success' => true, 'message' => 'Progress updated successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update progress']);
    }
    exit();
}

// Handle achievement deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_achievement') {
    $goal_id = $conn->real_escape_string($_POST['goal_id']);
    
    $sql = "DELETE FROM financial_goals 
            WHERE id = '$goal_id' 
            AND user_id = '$user_id' 
            AND status = 'Achieved'";
    
    if ($conn->query($sql)) {
        echo json_encode(['success' => true, 'message' => 'Achievement deleted successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to delete achievement']);
    }
    exit();
}

// Fetch user's goals
$goals_query = "SELECT * FROM financial_goals WHERE user_id = '$user_id' ORDER BY created_at DESC";
$goals_result = $conn->query($goals_query);
$goals = [];
if ($goals_result && $goals_result->num_rows > 0) {
    while ($row = $goals_result->fetch_assoc()) {
        $goals[] = $row;
    }
}

// Fetch user's achievements (goals that are achieved)
$achievements_query = "SELECT * FROM financial_goals 
                       WHERE user_id = '$user_id' AND status = 'Achieved' 
                       ORDER BY target_date ASC";
$achievements_result = $conn->query($achievements_query);
$achievements = [];
if ($achievements_result->num_rows > 0) {
    while ($row = $achievements_result->fetch_assoc()) {
        $achievements[] = $row;
    }
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FinanceFlow - Goal Tracking & Achievements</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <!-- <link rel="stylesheet" href="../assets/css/goal_tracking.css"> -->
    <style>
        <?php include "../assets/css/goal_tracking.css";?>
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <a href="#" class="logo">FinanceFlow</a>
            <ul class="nav-menu">
                <li><a href="../view/services.php" class="nav-link">Back to Services</a></li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <div class="dashboard-grid">
            <!-- Goals Section -->
            <div class="goals-section">
                <div class="section-header">
                    <h2>Financial Goals</h2>
                    <button class="add-goal-btn" onclick="openGoalModal()">
                        <i class="fas fa-plus"></i> Add New Goal
                    </button>
                </div>
                <div id="goals-container">
                    <?php foreach ($goals as $goal): ?>
                        <div class="goal-card" data-goal-id="<?php echo $goal['id']; ?>">
                            <h3><?php echo htmlspecialchars($goal['goal_name']); ?></h3>
                            <p>Category: <?php echo htmlspecialchars($goal['category']); ?></p>
                            <div class="goal-progress">
                                <p>$<?php echo number_format($goal['saved_amount'], 2); ?> / $<?php echo number_format($goal['target_amount'], 2); ?></p>
                                <?php 
                                $progress_percentage = ($goal['saved_amount'] / $goal['target_amount']) * 100;
                                $progress_class = $progress_percentage >= 100 ? 'achieved' : '';
                                ?>
                                <div class="progress-bar <?php echo $progress_class; ?>" style="width: <?php echo min($progress_percentage, 100); ?>%"></div>
                            </div>
                            <div class="goal-details">
                                <p>Target Date: <?php echo date('M d, Y', strtotime($goal['target_date'])); ?></p>
                                <p>Status: <?php echo htmlspecialchars($goal['status']); ?></p>
                            </div>
                            <button class="update-progress-btn" onclick="openUpdateProgressModal(
                                <?php echo $goal['id']; ?>, 
                                <?php echo $goal['target_amount']; ?>, 
                                <?php echo $goal['saved_amount']; ?>
                            )">Update Progress</button>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Achievements Section -->
            <div class="achievements-section">
                <h2>Achievements</h2>
                <div class="achievement-grid">
                    <?php foreach ($achievements as $achievement): ?>
                        <div class="achievement-card">
                            <i class="fas fa-trophy"></i>
                            <h3><?php echo htmlspecialchars($achievement['goal_name']); ?></h3>
                            <p>Achieved: $<?php echo number_format($achievement['saved_amount'], 2); ?></p>
                            <p>Date: <?php echo date('M d, Y', strtotime($achievement['target_date'])); ?></p>
                            <button class="delete-achievement-btn" onclick="deleteAchievement(<?php echo $achievement['id']; ?>)">
                                <i class="fas fa-trash"></i> Delete
                            </button>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Goal Modal -->
    <div id="goalModal" class="modal">
        <div class="modal-content">
            <h2>Create New Goal</h2>
            <form id="goalForm">
                <div class="form-group">
                    <label for="goalName">Goal Name</label>
                    <input type="text" id="goalName" required>
                </div>
                <div class="form-group">
                    <label for="goalAmount">Target Amount ($)</label>
                    <input type="number" id="goalAmount" required>
                </div>
                <div class="form-group">
                    <label for="goalDate">Target Date</label>
                    <input type="date" id="goalDate" required>
                </div>
                <div class="form-group">
                    <label for="goalCategory">Category</label>
                    <select id="goalCategory" required>
                        <option value="Savings">Savings</option>
                        <option value="Investment">Investment</option>
                        <option value="Debt Repayment">Debt Repayment</option>
                        <option value="Emergency Fund">Emergency Fund</option>
                    </select>
                </div>
                <div class="btn-group">
                    <button type="submit" class="add-goal-btn">Create Goal</button>
                    <button type="button" onclick="closeGoalModal()" style="background: #666;">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Update Progress Modal -->
    <div id="updateProgressModal" class="modal">
        <div class="modal-content">
            <h2>Update Goal Progress</h2>
            <form id="updateProgressForm">
                <input type="hidden" id="updateGoalId">
                <div class="form-group">
                    <label for="savedAmount">Amount Saved ($)</label>
                    <input type="number" id="savedAmount" required>
                </div>
                <div class="btn-group">
                    <button type="submit" class="add-goal-btn">Update Progress</button>
                    <button type="button" onclick="closeUpdateProgressModal()" style="background: #666;">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <div id="celebrate" class="celebrate">🎉</div>
    <script src="../assets/js/goal_tracking.js"></script>
</body>
</html>