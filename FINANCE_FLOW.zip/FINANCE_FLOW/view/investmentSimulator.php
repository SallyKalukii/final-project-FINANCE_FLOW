<?php
session_start();

$config_file = '../db/config.php';
if (file_exists($config_file)) {
    include $config_file;
} else {
    error_log("Database configuration file missing");
    $error_message = "System configuration error. Please contact support.";
    die($error_message);
}

// Validate and sanitize inputs
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    // Validate and sanitize inputs
    $initialInvestment = filter_input(INPUT_POST, 'initialInvestment', FILTER_VALIDATE_FLOAT) ?: 0.00;
    $period = filter_input(INPUT_POST, 'period', FILTER_VALIDATE_INT) ?: 0;
    $monthlyContribution = filter_input(INPUT_POST, 'monthlyContribution', FILTER_VALIDATE_FLOAT) ?: 0.00;
    $riskTolerance = filter_input(INPUT_POST, 'riskTolerance', FILTER_SANITIZE_STRING);
    $selectedAssets = isset($_POST['selectedAssets']) ? $_POST['selectedAssets'] : [];

    // Debug input values
    error_log("POST data: " . print_r($_POST, true));

    // Validation
    if ($initialInvestment > 0 && $period > 0 && isset($_SESSION['user_id']) && !empty($selectedAssets)) {
        
        $userId = intval($_SESSION['user_id']);
        $assetName = $selectedAssets[0]; // Get first selected asset
        
        // Calculate return rate
        $returnRate = 0.00;
        switch($riskTolerance) {
            case 'Conservative':
                $returnRate = 6.00;
                break;
            case 'Moderate':
                $returnRate = 8.00;
                break;
            case 'Aggressive':
                $returnRate = 10.00;
                break;
        }

        error_log("Received POST data: " . print_r($_POST, true));

        // Calculate return amount
        $monthlyRate = $returnRate / 100 / 12;
        $months = $period * 12;
        $futureValue = $initialInvestment;
        
        for ($i = 1; $i <= $months; $i++) {
            $futureValue = ($futureValue + $monthlyContribution) * (1 + $monthlyRate);
        }
        
        $returnAmount = max(0, $futureValue - ($initialInvestment + ($monthlyContribution * $months)));

        // Ensure all decimal values are properly formatted
        $initialInvestment = number_format($initialInvestment, 2, '.', '');
        $monthlyContribution = number_format($monthlyContribution, 2, '.', '');
        $returnAmount = number_format($returnAmount, 2, '.', '');
        $returnRate = number_format($returnRate, 2, '.', '');

        mysqli_begin_transaction($conn);

        try {
            // Debug values before insertion
            error_log("Values before insertion:");
            error_log("User ID: $userId");
            error_log("Asset Name: $assetName");
            error_log("Investment Amount: $initialInvestment");
            error_log("Monthly Contribution: $monthlyContribution");
            error_log("Return Amount: $returnAmount");
            error_log("Period: $period");
            error_log("Risk: $riskTolerance");
            error_log("Return Rate: $returnRate");

            $stmt = $conn->prepare("
                INSERT INTO investment_simulations (
                    user_id,
                    asset_name,
                    investment_amount,
                    monthly_contributions,
                    return_amount,
                    investment_period,
                    risk,
                    simulation_date,
                    return_rate
                ) VALUES (?, ?, ?, ?, ?, ?, ?, CURDATE(), ?)
            ");

            if (!$stmt) {
                throw new Exception("Prepare failed: " . $conn->error);
            }

            $stmt->bind_param(
                "isdddisd",
                $userId,
                $assetName,
                $initialInvestment,
                $monthlyContribution,
                $returnAmount,
                $period,
                $riskTolerance,
                $returnRate
            );
            
            if (!$stmt->execute()) {
                throw new Exception("Execute failed: " . $stmt->error);
            }

            mysqli_commit($conn);

            echo json_encode([
                'status' => 'success',
                'message' => 'Simulation saved successfully'
            ]);
            exit;

        } catch (Exception $e) {
            mysqli_rollback($conn);
            error_log("Simulation save error: " . $e->getMessage());
            echo json_encode([
                'status' => 'error',
                'message' => 'Failed to save simulation: ' . $e->getMessage()
            ]);
            exit;
        }
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Invalid input data. Please check your inputs.'
        ]);
        exit;
    }
}

// Fetch existing simulations for the user
$investments = [];
if (isset($_SESSION['user_id'])) {
    $userId = intval($_SESSION['user_id']);
    $query = "SELECT * FROM investment_simulations WHERE user_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $investments[] = $row;
    }
}

//handles the success message. 
if (isset($_SESSION['simulation_status'])) {
    $simulationStatus = $_SESSION['simulation_status'];
    echo "<script>alert('" . htmlspecialchars($simulationStatus['message']) . "');</script>";
    unset($_SESSION['simulation_status']); // Clear the message after displaying
}

// Close the connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>FinanceFlow - Investment Simulator</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <!-- <link rel="stylesheet" href="../assets/css/investment_simulator.css"> -->
    <style>
        <?php include "../assets/css/investment_simulator.css";?>
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <a href="#" class="logo">FinanceFlow</a>
            <ul class="nav-menu">
                <li><a href="../view/services.php" class="nav-link">Back to Services</a></li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <div class="simulator-header">
            <h1>Investment Simulator</h1>
            <p>Explore different investment scenarios and understand potential returns</p>
        </div>

        <div class="simulator-grid">
            <div class="input-card">
                <form id="investmentForm" method="POST" onsubmit="event.preventDefault(); simulateInvestment();">
                    <div class="input-group">
                        <label>Initial Investment ($)</label>
                        <input type="number"id="initialInvestment" name="initialInvestment" required min="100">
                    </div>

                    <div class="input-group">
                        <label>Investment Period (Years)</label>
                        <input type="number" id="period" name="period" required min="1" max="30">
                    </div>

                    <div class="input-group">
                        <label>Monthly Contribution ($)</label>
                        <input type="number" id="monthlyContribution" name="monthlyContribution" required min="0">
                    </div>

                    <div class="input-group">
                        <label>Risk Tolerance</label>
                        <select name="riskTolerance" id="riskTolerance" required>
                            <option value="">Select Risk Tolerance</option>
                            <option value="Conservative">Conservative</option>
                            <option value="Moderate">Moderate</option>
                            <option value="Aggressive">Aggressive</option>
                        </select>
                    </div>

                    <div class="input-group">
                        <label>Asset Allocation</label>
                        <select name="selectedAssets[]" id="assetAllocation" multiple required>
                            <!-- Options will be dynamically populated based on the selected risk tolerance -->
                        </select>
                    </div>

                    <button type="button" onclick="simulateInvestment()">
                        <i class="fas fa-calculator"></i> Submit Simulation
                    </button>
                </form>
            </div>


            <div class="results-card">
                <div class="metrics-grid">
                    <div class="metric-card">
                        <i class="fas fa-coins"></i>
                        <h3>Total Investment</h3>
                        <div id="totalInvestment" class="metric-value">$0</div>
                    </div>
                    <div class="metric-card">
                        <i class="fas fa-chart-pie"></i>
                        <h3>Expected Returns</h3>
                        <div id="expectedReturns" class="metric-value">$0</div>
                    </div>
                    <div class="metric-card">
                        <i class="fas fa-tachometer-alt"></i>
                        <h3>Risk Level</h3>
                        <div id="riskLevel" class="metric-value">Low</div>
                    </div>
                </div>

                <div class="chart-container">
                    <canvas id="investmentChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <script>
        let chart;
        let selectedAssets = new Set();

        // Function to get returns for an asset based on risk tolerance
        function getAssetReturns(asset, riskTolerance) {
            const baseReturns = {
                'Stocks': { 'Conservative': 6.00, 'Moderate': 8.00, 'Aggressive': 10.00 },
                'Bonds': { 'Conservative': 3.00, 'Moderate': 4.00, 'Aggressive': 5.00 },
                'Mutual Funds': { 'Conservative': 5.00, 'Moderate': 7.00, 'Aggressive': 9.00 },
                'Crypto': { 'Conservative': 10.00, 'Moderate': 15.00, 'Aggressive': 20.00 }
            };
            return baseReturns[asset][riskTolerance];
        }

        // Function to simulate investment and update UI
        function simulateInvestment() {
            console.log('Simulation started'); // Debug line

            const initialInvestment = parseFloat(document.getElementById('initialInvestment').value);
            const period = parseInt(document.getElementById('period').value);
            const monthlyContribution = parseFloat(document.getElementById('monthlyContribution').value);
            const riskTolerance = document.getElementById('riskTolerance').value;
            const assetAllocation = document.getElementById('assetAllocation');

            console.log('Values:', { // Debug line
                initialInvestment,
                period,
                monthlyContribution,
                riskTolerance
            });
            
            // Validation: Ensure all inputs are provided and valid
            if (isNaN(initialInvestment) || initialInvestment <= 0) {
                alert('Please enter a valid initial investment.');
                return;
            }

            if (isNaN(period) || period <= 0 || period > 30) {
                alert('Please enter a valid investment period between 1 and 30 years.');
                return;
            }

            if (isNaN(monthlyContribution) || monthlyContribution < 0) {
                alert('Please enter a valid monthly contribution.');
                return;
            }

            if (!riskTolerance) {
                alert('Please select a risk tolerance level.');
                return;
            }

            // Get selected assets
            const selectedAssets = Array.from(assetAllocation.selectedOptions).map(option => option.value);

            // Check if at least one asset is selected
            if (selectedAssets.length === 0) {
                alert('Please select at least one asset type');
                return;
            }

            // Calculate the average return for selected assets
            let averageReturn = 0;
            selectedAssets.forEach(asset => {
                averageReturn += getAssetReturns(asset, riskTolerance);
            });
            averageReturn /= selectedAssets.length;

            // Calculate investment growth
            const monthlyRate = averageReturn / 100 / 12;
            const months = period * 12;
            let currentValue = initialInvestment;
            const projectedValues = [];

            // Calculate projected values over time
            for (let i = 0; i <= months; i++) {
                projectedValues.push({
                    month: i,
                    value: currentValue
                });
                currentValue = currentValue * (1 + monthlyRate) + monthlyContribution;
            }

            // Calculate final values
            const totalContributed = initialInvestment + (monthlyContribution * months);
            const finalValue = projectedValues[projectedValues.length - 1].value;
            const returnAmount = finalValue - totalContributed;

            // Update UI
            document.getElementById('totalInvestment').textContent = `$${totalContributed.toFixed(2)}`;
            document.getElementById('expectedReturns').textContent = `$${returnAmount.toFixed(2)}`;
            document.getElementById('riskLevel').textContent = `${averageReturn.toFixed(1)}%`;

            // Update chart
            updateChart(projectedValues);

            // Create FormData and send to server
            const formData = new FormData();
            formData.append('initialInvestment', initialInvestment);
            formData.append('period', period);
            formData.append('monthlyContribution', monthlyContribution);
            formData.append('riskTolerance', riskTolerance);
            formData.append('selectedAssets[]', selectedAssets[0]);
            formData.append('return_amount', returnAmount.toFixed(2));

            // Send to current page
            fetch(window.location.href, {
                method: 'POST',
                body: formData
            })
            .then(response => {
                console.log('Raw response:', response); // Debug line
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                console.log('Processed data:', data); // Debug line
                if (data.status === 'success') {
                    alert('Simulation saved successfully');
                } else {
                    throw new Error(data.message || 'Server returned an error');
                }
            })
            // .catch(error => {
            //     console.error('Detailed error:', error); // More detailed error logging
            //     console.error('Error stack:', error.stack); // Stack trace
            //     alert(`An unexpected error occurred: ${error.message}`);
            // });
        }

        // Function to update the chart with the projected values
        function updateChart(data) {
            const ctx = document.getElementById('investmentChart').getContext('2d');

            if (chart) {
                chart.destroy(); // Destroy existing chart before creating a new one
            }

            chart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: data.map(d => `Year ${Math.floor(d.month / 12)}`),
                    datasets: [{
                        label: 'Portfolio Value',
                        data: data.map(d => d.value),
                        borderColor: '#2563eb',
                        backgroundColor: 'rgba(37, 99, 235, 0.1)',
                        fill: true,
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: true
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: value => `$${value.toLocaleString()}`
                            }
                        }
                    }
                }
            });
        }
        document.getElementById('riskTolerance').addEventListener('change', function() {
            const riskLevel = this.value;
            const assets = [
                { name: 'Stocks', risk: 'Conservative', return: 6.00 },
                { name: 'Stocks', risk: 'Moderate', return: 8.00 },
                { name: 'Stocks', risk: 'Aggressive', return: 10.00 },
                { name: 'Bonds', risk: 'Conservative', return: 3.00 },
                { name: 'Bonds', risk: 'Moderate', return: 4.00 },
                { name: 'Bonds', risk: 'Aggressive', return: 5.00 },
                { name: 'Mutual Funds', risk: 'Conservative', return: 5.00 },
                { name: 'Mutual Funds', risk: 'Moderate', return: 7.00 },
                { name: 'Mutual Funds', risk: 'Aggressive', return: 9.00 },
                { name: 'Crypto', risk: 'Conservative', return: 10.00 },
                { name: 'Crypto', risk: 'Moderate', return: 15.00 },
                { name: 'Crypto', risk: 'Aggressive', return: 20.00 }
            ];

            // Filter assets based on the selected risk tolerance
            const filteredAssets = assets.filter(asset => asset.risk === riskLevel);

            // Populate the assetAllocation dropdown
            const assetDropdown = document.getElementById('assetAllocation');
            assetDropdown.innerHTML = ''; // Clear existing options
            filteredAssets.forEach(asset => {
                const option = document.createElement('option');
                option.value = asset.name;
                option.textContent = `${asset.name} (${asset.return}% return)`;
                assetDropdown.appendChild(option);
            });
        });


    </script>
</body>
</html>
