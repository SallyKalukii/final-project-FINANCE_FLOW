<?php 


session_start();

if (!isset($_SESSION['user_id'])) {
    error_log("No user_id in session");
    die("User not logged in");
}
error_log("Current user_id: " . $_SESSION['user_id']);

// Load the database configuration file
$config_file = '../db/config.php';
if (file_exists($config_file)) {
    include $config_file;
} else {
    error_log("Database configuration file missing");
    $error_message = "System configuration error. Please contact support.";
    die($error_message);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['moduleId'])) {
    $moduleId = intval($_POST['moduleId']);
    $userId = $_SESSION['user_id'];
    
    // Debug logging
    error_log("Attempting to update progress for user $userId and module $moduleId");
    
    // Insert or update progress in user_module_progress table
    $stmt = $conn->prepare("
        INSERT INTO user_module_progress (user_id, module_id, progress, completed_at)
        VALUES (?, ?, 100, CURRENT_TIMESTAMP)
        ON DUPLICATE KEY UPDATE 
            progress = 100,
            completed_at = CURRENT_TIMESTAMP
    ");
    
    if (!$stmt) {
        error_log("Prepare failed: " . $conn->error);
        echo json_encode(['success' => false, 'error' => 'Prepare failed']);
        exit;
    }
    
    $stmt->bind_param("ii", $userId, $moduleId);
    
    if (!$stmt->execute()) {
        error_log("Execute failed: " . $stmt->error);
        echo json_encode(['success' => false, 'error' => 'Execute failed: ' . $stmt->error]);
        exit;
    }
    
    if ($stmt->affected_rows > 0) {
        echo json_encode(['success' => true]);
    } else {
        error_log("No rows affected. User ID: $userId, Module ID: $moduleId");
        echo json_encode(['success' => false, 'error' => 'No rows affected']);
    }
    
    $stmt->close();
    exit;
}

// Fetch modules from database with user-specific progress
$sql = "SELECT lm.id, lm.module_name, lm.description, lm.content,
        COALESCE(ump.progress, 0) as progress
        FROM learning_modules lm
        LEFT JOIN user_module_progress ump 
            ON lm.id = ump.module_id 
            AND ump.user_id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();

// Check if any modules exist
$modules = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $modules[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FinanceFlow - Learning Center</title>
    <!-- <link rel="stylesheet" href="../assets/css/learning_center.css"> -->
    <style>
        <?php include "../assets/css/learning_center.css";?>

        .nav-link {
            color: #800020;
            text-decoration: none;
            transition: color 0.3s;
        }
    </style>

</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar">
        <div class="nav-container">
            <a href="#" class="logo">FinanceFlow</a>
            <ul class="nav-menu">
                <li><a href="../view/services.php" class="nav-link">Back to Services</a></li>
            </ul>
        </div>
    </nav>

    <div class="learning-container">
        <div class="learning-header">
            <h1>Financial Learning Center</h1>
            <p>Master your financial journey with our interactive learning modules</p>
        </div>

        <div class="modules-grid">
            <?php foreach($modules as $row): ?>
                <div class="module-card" data-module-id="<?php echo $row['id']; ?>">
                    <h3><?php echo htmlspecialchars($row['module_name']); ?></h3>
                    <p><?php echo htmlspecialchars($row['description']); ?></p>
                    
                    <!-- Progress Bar -->
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: <?php echo intval($row['progress']); ?>%"></div>
                    </div>
                    <span>Progress: <?php echo intval($row['progress']); ?>%</span>
                    
                    
                    
                    <!-- Button to continue learning -->
                    <button onclick='showContent(<?php echo json_encode(htmlspecialchars($row['content'], ENT_QUOTES)); ?>, <?php echo $row['id']; ?>)'>

                        Continue Reading
                    </button>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Content Display -->
        <div id="moduleContent" class="module-content">
            <!-- Dynamic content will be displayed here -->
        </div>
    </div>

    <!-- <script src="../assets/js/learning_center.js"></script> -->

    <script>
    let currentModuleId = null;

    function showContent(content, moduleId) {
        try {
            currentModuleId = moduleId;
            const contentDiv = document.getElementById('moduleContent');
            const finishedButton = document.getElementById('finishedReading');
            
            // Decode the content properly
            const decodedContent = content.replace(/\\n/g, '\n').replace(/\\'/g, "'");
            
            // Format and display content
            const formattedContent = decodedContent
                .split('\n\n')
                .map(paragraph => `<p>${paragraph}</p>`)
                .join('');
            
            contentDiv.innerHTML = DOMPurify.sanitize(formattedContent);
            finishedButton.style.display = 'block';
            
            // Scroll to content
            contentDiv.scrollIntoView({ behavior: 'smooth' });
        } catch (error) {
            console.error('Error displaying content:', error);
            alert('Unable to load module content');
        }
    }

    function updateProgress() {
        if (!currentModuleId) {
            console.error('No module selected');
            return;
        }
        
        console.log('Updating progress for module:', currentModuleId);
        
        fetch(window.location.href, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `moduleId=${currentModuleId}`
        })
        .then(response => response.json())
        .then(data => {
            console.log('Server response:', data);
            if (data.success) {
                // Update progress bar visually
                const moduleCard = document.querySelector(`[data-module-id="${currentModuleId}"]`);
                if (moduleCard) {
                    const progressBar = moduleCard.querySelector('.progress-fill');
                    const progressText = moduleCard.querySelector('span');
                    
                    progressBar.style.width = '100%';
                    progressText.textContent = 'Progress: 100%';
                    
                    // Show congratulations popup
                    document.getElementById('congratsPopup').style.display = 'flex';
                }
            } else {
                console.error('Failed to update progress:', data.error);
                alert('Failed to update progress. Please try again.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while updating progress.');
        });
    }

    function closeCongratsPopup() {
        const popup = document.getElementById('congratsPopup');
        const contentDiv = document.getElementById('moduleContent');
        const finishedButton = document.getElementById('finishedReading');
        
        popup.style.opacity = '0';
        popup.style.transition = 'opacity 0.5s ease-out';
        
        setTimeout(() => {
            popup.style.display = 'none';
            popup.style.opacity = '1';
            contentDiv.innerHTML = '';
            finishedButton.style.display = 'none';
        }, 500);
    }

    // Add event listener for Finished Reading button
    document.addEventListener('DOMContentLoaded', function() {
        const finishedButton = document.getElementById('finishedReading');
        if (finishedButton) {
            finishedButton.addEventListener('click', updateProgress);
        }
    });
    </script>

    <!-- Add DOMPurify for additional security -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/dompurify/3.0.1/purify.min.js"></script>


    <button id="finishedReading" style="display: none;" class="finish-button">
        Finished Reading
    </button>

    <div id="congratsPopup" class="popup-overlay" style="display: none;">
        <div class="popup-container">
            <div class="popup-content">
                <div class="trophy-icon">
                    🏆
                </div>
                <h2>Congratulations!</h2>
                <p>You've completed this module!</p>
                <button onclick="closeCongratsPopup()" class="close-btn">Continue Learning</button>
            </div>
        </div>
    </div>
</body>
</html>

<?php 
$conn->close();
?>