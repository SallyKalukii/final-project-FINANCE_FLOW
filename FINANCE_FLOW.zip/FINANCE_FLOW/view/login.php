<?php
    session_start();

    // Load the database configuration file
    $config_file = '../db/config.php';
    if (file_exists($config_file)) {
        include $config_file;
    } else {
        error_log("Database configuration file missing");
        $error_message = "System configuration error. Please contact support.";
        die($error_message);
    }

    // Initialize error message variable
    $error_message = '';

    // Function to check login attempts
    function checkLoginAttempts($email, $conn) {
        $stmt = $conn->prepare("
            SELECT COUNT(*) as count 
            FROM login_attempts_f
            WHERE email = ? AND attempt_time > DATE_SUB(NOW(), INTERVAL 15 MINUTE)
        ");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $count = $result->fetch_assoc()['count'];
        return $count;
    }

    // Function to record failed login attempt
    function recordLoginAttempt($email, $conn) {
        $stmt = $conn->prepare("INSERT INTO login_attempts_f (email, attempt_time) VALUES (?, NOW())");
        $stmt->bind_param("s", $email);
        $stmt->execute();
    }

    // Function to get dashboard URL based on role
    function getDashboardByRole($role) {
        switch ($role) {
            case 1: // Admin
                return '../view/admin/dashboard.php';
            case 2: // Regular User
                return '../view/user/dashboard.php';
            default: // Fallback
                return '../view/default/dashboard.php';
        }
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $errors = [];
        
        // Validate and sanitize inputs
        $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
        $password = trim($_POST['password']);
        $remember = isset($_POST['chk']) ? $_POST['chk'] : '';

        // Input validation
        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Please enter a valid email address.";
        }
        
        if (empty($password)) {
            $errors[] = "Password is required.";
        }

        // If no validation errors, proceed with login
        if (empty($errors)) {
            try {
                // Check for too many login attempts
                $attempts = checkLoginAttempts($email, $conn);
                if ($attempts >= 5) {
                    $error_message = "Too many failed login attempts. Please try again in 15 minutes.";
                    error_log("Blocked login attempt for email: " . $email . " - Too many attempts");
                } else {
                    // Query the finance_users table
                    $stmt = $conn->prepare("
                        SELECT user_id, fname, lname, role, email, password 
                        FROM finance_users 
                        WHERE email = ?
                    ");
                    $stmt->bind_param("s", $email);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    $user = $result->fetch_assoc();

                    if ($user && password_verify($password, $user['password'])) {
                        // Successful login
                        session_regenerate_id(true); // Prevent session fixation
                        
                        $_SESSION['user_id'] = $user['user_id'];
                        $_SESSION['fname'] = $user['fname'];
                        $_SESSION['lname'] = $user['lname'];
                        $_SESSION['email'] = $user['email'];
                        $_SESSION['role'] = $user['role'];
                        $_SESSION['last_activity'] = time();

                        // Handle remember me functionality
                        if ($remember == 'I agree') {
                            $token = bin2hex(random_bytes(32));
                            setcookie('remember_me', $token, time() + (30 * 24 * 60 * 60), '/', '', true, true);
                            
                            // Store token in database
                            $stmt = $conn->prepare("
                                INSERT INTO remember_tokens_f (user_id, token, expires) 
                                VALUES (?, ?, ?)
                            ");
                            $expires = date('Y-m-d H:i:s', time() + (30 * 24 * 60 * 60));
                            $stmt->bind_param("iss", $user['user_id'], $token, $expires);
                            $stmt->execute();
                        }

                        // Redirect to dashboard
                        $dashboard_url = getDashboardByRole($user['role']);
                        // Show success popup
                        echo '
                        <div id="successPopup" class="popup-overlay">
                            <div class="popup-container">
                                <div class="popup-content">
                                    <div class="success-checkmark">
                                        <div class="check-icon">
                                            <span class="icon-line line-tip"></span>
                                            <span class="icon-line line-long"></span>
                                            <div class="icon-circle"></div>
                                            <div class="icon-fix"></div>
                                        </div>
                                    </div>
                                    <h2>Welcome Back!</h2>
                                    <p>Login successful.</p>
                                    <button onclick="closePopup()" class="close-btn">Continue to Services</button>
                                </div>
                            </div>
                        </div>

                        <script>
                        function closePopup() {
                            document.getElementById("successPopup").style.opacity = "0";
                            document.getElementById("successPopup").style.transition = "opacity 0.5s ease-out";
                            setTimeout(function() {
                                window.location.href = "services.php";
                            }, 500);
                        }

                        setTimeout(function() {
                            closePopup();
                        }, 15000);
                        </script>';
                    } else {
                        // Failed login
                        recordLoginAttempt($email, $conn);
                        $error_message = "Invalid email or password.";
                        error_log("Failed login attempt for email: " . $email);
                    }
                }
            } catch (Exception $e) {
                error_log("Login Error: " . $e->getMessage());
                $error_message = "An error occurred during login. Please try again later.";
            }
        } else {
            $error_message = implode("<br>", $errors);
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log In - Recipe Sharing Platform</title>
    <style>
        <?php include "../assets/css/mystylelogin.css";?>
    </style>
</head>
<body>    
    <div class="container">
        <div class="form-box">
            <div class="login-box form">
                <div class="LogIn">
                    <h2>Log In</h2>
                    <?php if (!empty($error_message)): ?>
                        <div class="alert-container">
                            <div class="alert alert-error">
                                <?php echo htmlspecialchars($error_message); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" id="login-form">
                        <div class="input-box">
                            <label for="email">Email</label>
                            <input type="email" 
                                   name="email" 
                                   id="email" 
                                   placeholder="Enter your email" 
                                   value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                                   required>
                        </div>

                        <div class="input-box">
                            <label for="password">Password</label>
                            <input type="password" 
                                   name="password" 
                                   id="password" 
                                   placeholder="Enter your password" 
                                   required>
                        </div>

                        <button type="submit" class="button button1" id="loginbutton">Log In</button>

                        <div class="remember-forgot">
                            <label class="checkbox-container">
                                <input type="checkbox" id="chk" name="chk" value="I agree">
                                <span style="font-size: 11px;color: rgb(197, 238, 241);">Remember me</span>
                            </label>
                        </div>

                        <div class="sign-up link">
                            <a href="register.php" style="font-size: 11px; color: white; text-decoration: none; font-weight: bold;">
                                Create a new account
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Client-side validation -->
    <script src="../../assets/js/loginScript.js"></script>
</body>
</html>