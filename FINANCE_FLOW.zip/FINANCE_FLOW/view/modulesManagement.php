<?php
session_start();

$config_file = '../db/config.php';
    if (file_exists($config_file)) {
        include $config_file;
    } else {
        error_log("Database configuration file missing");
        $error_message = "System configuration error. Please contact support.";
        die($error_message);
    }

// Check if user is logged in and has admin/moderator privileges
if (!isset($_SESSION['user_id']) || $_SESSION['role'] > 2) {
    header("Location: ../view/login.php");
    exit();
}

// Handle module creation
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['create_module'])) {
    $module_name = $_POST['module_name'];
    $description = $_POST['description'];
    $content = $_POST['content'];
    
    $stmt = $conn->prepare("INSERT INTO learning_modules (module_name, description, content) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $module_name, $description, $content);
    
    if ($stmt->execute()) {
        $success_message = "Module created successfully!";
    } else {
        $error_message = "Error creating module: " . $stmt->error;
    }
    $stmt->close();
}

// Handle module update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_module'])) {
    $module_id = $_POST['id'];
    $module_name = $_POST['module_name'];
    $description = $_POST['description'];
    $content = $_POST['content'];
    
    $stmt = $conn->prepare("UPDATE learning_modules SET module_name = ?, description = ?, content = ? WHERE id = ?");
    $stmt->bind_param("sssi", $module_name, $description, $content, $module_id);
    
    if ($stmt->execute()) {
        $success_message = "Module updated successfully!";
    } else {
        $error_message = "Error updating module: " . $stmt->error;
    }
    $stmt->close();
}

// Handle module deletion
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_module'])) {
    $module_id = $_POST['id'];
    
    $stmt = $conn->prepare("DELETE FROM learning_modules WHERE id = ?");
    $stmt->bind_param("i", $module_id);
    
    if ($stmt->execute()) {
        $success_message = "Module deleted successfully!";
    } else {
        $error_message = "Error deleting module: " . $stmt->error;
    }
    $stmt->close();
}

// Fetch existing modules
$modules_query = "SELECT * FROM learning_modules ORDER BY created_at DESC";
$modules_result = $conn->query($modules_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FinanceFlow - Modules Management</title>
    <style>
        <?php include "../assets/css/modulesManagement.css";?>
    </style>
</head>
<body>
    <div class="container">
        <div class="modules-management">
            <div class="modules-header">
                
                <div class="back-to-services">
                    <a href="../view/services.php" class="btn btn-secondary">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-left">
                            <line x1="19" y1="12" x2="5" y2="12"></line>
                            <polyline points="12 19 5 12 12 5"></polyline>
                        </svg>
                        Back to Services
                    </a>
                </div>
                <h1>Learning Modules Management</h1>
                <p>Create, Update, and Delete Learning Modules</p>
            </div>

            <?php 
            if (isset($success_message)) {
                echo "<div class='alert alert-success'>$success_message</div>";
            }
            if (isset($error_message)) {
                echo "<div class='alert alert-danger'>$error_message</div>";
            }
            ?>

            <div class="module-form">
                <h2>Create New Module</h2>
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="module_name">Module Name</label>
                        <input type="text" id="module_name" name="module_name" required>
                    </div>
                    <div class="form-group">
                        <label for="description">Description</label>
                        <textarea id="description" name="description" rows="4" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="content">Module Content</label>
                        <textarea id="content" name="content" class="content-editor" rows="10" placeholder="Enter module content here."><?php echo isset($module['content']) ? htmlspecialchars($module['content']) : ''; ?></textarea>
                    </div>
                    <button type="submit" name="create_module" class="btn">Create Module</button>
                </form>
            </div>

            <div class="modules-list">
                <h2>Existing Modules</h2>
                <?php 
                if ($modules_result->num_rows > 0) {
                    while ($module = $modules_result->fetch_assoc()) {
                ?>
                    <div class="module-item">
                        <div>
                            <strong><?php echo htmlspecialchars($module['module_name']); ?></strong>
                            <p><?php echo htmlspecialchars($module['description']); ?></p>
                            <details>
                                <summary>View Content</summary>
                                <div class="module-content"><?php echo $module['content']; ?></div>
                            </details>
                        </div>
                        <div class="module-actions">
                            <form method="POST" action="">
                                <input type="hidden" name="module_id" value="<?php echo $module['id']; ?>">
                                <button type="button" class="btn" onclick="editModule(
                                    '<?php echo htmlspecialchars($module['id']); ?>',
                                    '<?php echo htmlspecialchars($module['module_name']); ?>',
                                    '<?php echo htmlspecialchars($module['description']); ?>',
                                    `<?php echo htmlspecialchars($module['content']); ?>`
                                )">Edit</button>
                                <button type="submit" name="delete_module" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this module?')">Delete</button>
                            </form>
                        </div>
                    </div>
                <?php 
                    }
                } else {
                    echo "<p>No modules found. Create your first module!</p>";
                }
                ?>
            </div>
        </div>
    </div>

    <script>
        function editModule(id, name, description, content) {
            // Create edit form dynamically
            const editForm = `
                <form method="POST" action="">
                    <input type="hidden" name="module_id" value="${id}">
                    <div class="form-group">
                        <label>Module Name</label>
                        <input type="text" name="module_name" value="${name}" required>
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <textarea name="description" rows="4" required>${description}</textarea>
                    </div>
                    <div class="form-group">
                        <label>Content</label>
                        <textarea name="content" class="content-editor" rows="10">${content}</textarea>
                    </div>
                    <button type="submit" name="update_module" class="btn">Update Module</button>
                </form>
            `;

            // Replace the module item with edit form
            event.target.closest('.module-item').innerHTML = editForm;
        }
    </script>
</body>
</html>