<!DOCTYPE html>
<html lang="en">
<head>
    <title>User Registration</title>
    <style>
        <?php include "../assets/css/mystyle.css"; ?>
    </style>
</head>
<body>
    <?php
        ini_set('display_errors', 1); error_reporting(E_ALL);

        // Initialize variable to store the email error message
        $emailError = '';

        // Load the database configuration file
        $config_file = '../db/config.php';
        if (file_exists($config_file)) {
            include $config_file;
        } else {
            echo "Error: Unable to load database configuration file.";
            exit;
        }

        // Check if the form was submitted
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Collect input data and perform server-side validation
            $fname = trim($_POST['fname']);
            $lname = trim($_POST['lname']);
            $email = trim($_POST['email']);
            $password = trim($_POST['password']);
            
            $errors = [];

            // Validate first name
            if (empty($fname) || strlen($fname) < 1) {
                $errors[] = "First name is required and must be at least 1 character.";
            }

            // Validate last name
            if (empty($lname) || strlen($lname) < 1) {
                $errors[] = "Last name is required and must be at least 1 character.";
            }

            // Validate email
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errors[] = "A valid email address is required.";
            }

            // Validate password
            if (empty($password) || strlen($password) < 8) {
                $errors[] = "Password must be at least 8 characters.";
            }

            // Check if the email already exists
            $stmt = $conn->prepare("SELECT * FROM finance_users WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            $stmt->close();

            if ($result->num_rows > 0) {
                $emailError = "This email address is already registered.";
            } else {
                // Hash the password
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                // Prepare the SQL statement for inserting a new user
                $stmt = $conn->prepare("INSERT INTO finance_users (fname, lname, email, password, role, created_at, updated_at) VALUES (?, ?, ?, ?, ?, NOW(), NOW())");

                // Set default user role (e.g., 3 = normal user)
                $role = 3;

                // Bind parameters
                $stmt->bind_param("ssssi", $fname, $lname, $email, $hashed_password, $role);

                // Execute the statement and check for success
                if ($stmt->execute()) {
                    // Store success message in session
                    $_SESSION['success_message'] = true;

                    // Output the popup HTML
                    echo '
                    <div id="successPopup" class="popup-overlay">
                        <div class="popup-container">
                            <div class="popup-content">
                                <div class="success-checkmark">
                                    <div class="check-icon">
                                        <span class="icon-line line-tip"></span>
                                        <span class="icon-line line-long"></span>
                                        <div class="icon-circle"></div>
                                        <div class="icon-fix"></div>
                                    </div>
                                </div>
                                <h2>Congratulations!</h2>
                                <p>Your account has been created successfully.</p>
                                <button onclick="closePopup()" class="close-btn">Continue to Login</button>
                            </div>
                        </div>
                    </div>

                    <script>
                    function closePopup() {
                        document.getElementById("successPopup").style.opacity = "0";
                        document.getElementById("successPopup").style.transition = "opacity 0.5s ease-out";
                        setTimeout(function() {
                            window.location.href = "login.php";
                        }, 500);
                    }

                    setTimeout(function() {
                        closePopup();
                    }, 15000);
                    </script>
                    ';
                } else {
                    $errors[] = "Error: " . $stmt->error;
                }

                // Close statement and connection
                $stmt->close();
                $conn->close();
            }
        }
    ?>

    <!-- Display email error -->
    <?php if (!empty($emailError)): ?>
    <div class="alert-container">
        <div class="alert alert-error">
            <?php echo $emailError; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Display other validation errors -->
    <?php if (!empty($errors)): ?>
    <div class="alert-container">
        <?php foreach ($errors as $error): ?>
            <div class="alert alert-error">
                <?php echo $error; ?>
            </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <div class="container">
        <div class="form-box">
            <div class="signUp-box form">
                <div class="SignUp">
                    <h2>Sign Up</h2>
                    <form method="post" action="">
                        <div class="input-box">
                            <label for="fname">First Name</label>
                            <input type="text" name="fname" id="fname" placeholder="At least one character" required>
                        </div>

                        <div class="input-box">
                            <label for="lname">Last Name</label>
                            <input type="text" name="lname" id="lname" placeholder="At least one character" required>
                        </div>

                        <div class="input-box">
                            <label for="email">Email</label>
                            <input type="email" name="email" id="email" placeholder="Enter your email" required>
                        </div>

                        <div class="input-box">
                            <label for="password">Password</label>
                            <input type="password" name="password" id="password" placeholder="At least 8 characters" required>
                        </div>

                        <button class="button button1" id="register">Register</button><br>

                        <input type="checkbox" id="chk" name="chk" value="I agree" required>
                        <label for="chk" style="font-size: 11px; color: rgb(197, 238, 241);"> I agree to the terms and conditions</label><br>
                        <div class="log-in link">
                            <a href="login.php" style="font-size: 11px; color: white; text-decoration: none; font-weight: bold;">Already have an account? Log in</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- Client-side validation -->
    <script src='../../assets/js/registerScript.js'></script>
</body>
</html>
