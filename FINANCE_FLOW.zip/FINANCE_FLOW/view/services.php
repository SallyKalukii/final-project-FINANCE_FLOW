<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
$userName = htmlspecialchars($_SESSION['fname'] ?? 'Guest');
// User role-based access control
$user_role = $_SESSION['role'] ?? 3;

// Logout functionality
if (isset($_POST['logout'])) {
    // Destroy session
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Financial Services Portal</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #800020;
            --secondary-color:#800020 ;
            --background-color: #f4f6f7;
            --text-color: #2c3e50;
            --card-background: white;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-color: #800020;
            color: var(--text-color);
            line-height: 1.6;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            
        }



        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: var(--card-background);
            padding: 15px 25px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }

        .user-info {
            display: flex;
            align-items: center;
        }

        .user-info img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-right: 15px;
        }

        .logout-btn {
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .logout-btn:hover {
            background-color: #2980b9;
        }

        .services-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }

        .service-card {
            background-color: var(--card-background);
            border-radius: 10px;
            padding: 25px;
            text-align: center;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }

        .service-card:hover {
            transform: translateY(-10px);
        }

        .service-card i {
            font-size: 3rem;
            color: var(--primary-color);
            margin-bottom: 15px;
        }

        .service-card h3 {
            margin-bottom: 10px;
            color: var(--text-color);
            text-decoration: none;
        }

        .service-card p {
            color: #7f8c8d;
            font-size: 0.9rem;
            text-decoration: none;
        }
        .service-card a{
            text-decoration: none;
        }
        .home-btn {
            background-color: var(--primary-color);
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 5px;
            margin-right: 20px;
            display: inline-flex;
            align-items: center;
            transition: background-color 0.3s ease;
        }

        .home-btn i {
            margin-right: 8px;
        }

        .home-btn:hover {
            background-color:rgb(28, 65, 90);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="user-info">
                <a href="../index.php" class="home-btn">
                    <i class="fas fa-home"></i> Home
                </a>
                <div>
                    <h2>Welcome <?php echo htmlspecialchars($_SESSION['fname'] ?? 'finance_users'); ?>!</h2>
                    <?php 
                    if ($user_role == 3){
                        echo "User Portal";
                    }
                    else if ($user_role == 2 && $user_role == 1){
                        echo "Admin Portal";
                    }?>
                    
                </div>
            </div>
            <form method="post">
                <button type="submit" name="logout" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </button>
            </form>
        </div>

        <div class="services-grid <?php echo $user_role === 'user' ? '' : 'admin-services'; ?>">
            <?php if ($user_role === 3 || $user_role === 2 || $user_role === 1): ?>
                <!-- User Features -->
                <div class="service-card">
                    <a href="../view/admin/dashboard.php">
                        <div class="service-card-content">
                            <i class="fas fa-tachometer-alt"></i>
                            <h3>My Dashboard</h3>
                            <p>Comprehensive system overview and analytics</p>
                        </div>
                    </a>
                </div>
                <div class="service-card">
                    <a href="../view/spendingAnalysis.php">
                        <div class="service-card-content">
                            <i class="fas fa-chart-line"></i>
                            <h3>Spending Pattern Analysis</h3>
                            <p>Dive deep into your financial spending trends</p>
                        </div>
                    </a>
                </div>
                <div class="service-card">
                    <a href="../view/investmentSimulator.php">
                        <div class="service-card-content">
                            <i class="fas fa-calculator"></i>
                            <h3>Investment Simulation</h3>
                            <p>Simulate and plan your investment strategies</p>
                        </div>
                    </a>
                </div>
                <div class="service-card">
                    <a href="../view/goalTracking.php">
                        <div class="service-card-content">
                            <i class="fas fa-bullseye"></i>
                            <h3>Goal Tracking</h3>
                            <p>Set, monitor, and achieve your financial goals</p>
                        </div>
                    </a>
                </div>
                <div class="service-card">
                    <a href="../view/learningCenter.php">
                        <div class="service-card-content">
                            <i class="fas fa-graduation-cap"></i>
                            <h3>Learning Modules</h3>
                            <p>Enhance your financial literacy</p>
                        </div>
                    </a>
                </div>
            <?php endif; ?>

            <?php if ($user_role === 1 || $user_role === 2): ?>
                <!-- Admin Features -->
                <div class="service-card">
                    <a href="../view/admin/dashboard.php">
                        <div class="service-card-content">
                            <i class="fas fa-tachometer-alt"></i>
                            <h3>Admin Dashboard</h3>
                            <p>Comprehensive system overview and analytics</p>
                        </div>
                    </a>
                </div>
                <div class="service-card">
                    <a href="../view/userManagement.php">
                        <div class="service-card-content">
                            <i class="fas fa-users-cog"></i>
                            <h3>User Management</h3>
                            <p>Manage user accounts and permissions</p>
                        </div>
                    </a>
                </div>
                <div class="service-card">
                    <a href="../view/modulesManagement.php">
                        <div class="service-card-content">
                            <i class="fas fa-book-reader"></i>
                            <h3>Learning Modules Management</h3>
                            <p>Create and manage educational content</p>
                        </div>
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>