<?php
session_start();
require_once '../db/config.php';
require_once '../functions/auth_check.php'; 

// Fetch spending categories
$categories_query = "SELECT id, name FROM spending_categories";
$categories_result = mysqli_query($conn, $categories_query);
$categories = [];
while ($row = mysqli_fetch_assoc($categories_result)) {
    $categories[] = $row;
}

// Function to get spending data based on time period
function getSpendingData($conn, $user_id, $period = 'month') {
    $query = "";
    switch($period) {
        case 'month':
            $query = "SELECT c.name AS category, SUM(sp.amount) AS total_amount 
                      FROM spending_patterns sp
                      JOIN spending_categories c ON sp.category_id = c.id
                      WHERE sp.user_id = ? AND sp.transaction_date >= DATE_SUB(CURDATE(), INTERVAL 1 MONTH)
                      GROUP BY c.name";
            break;
        case 'quarter':
            $query = "SELECT c.name AS category, SUM(sp.amount) AS total_amount 
                      FROM spending_patterns sp
                      JOIN spending_categories c ON sp.category_id = c.id
                      WHERE sp.user_id = ? AND sp.transaction_date >= DATE_SUB(CURDATE(), INTERVAL 3 MONTH)
                      GROUP BY c.name";
            break;
        case 'halfYear':
            $query = "SELECT c.name AS category, SUM(sp.amount) AS total_amount 
                      FROM spending_patterns sp
                      JOIN spending_categories c ON sp.category_id = c.id
                      WHERE sp.user_id = ? AND sp.transaction_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
                      GROUP BY c.name";
            break;
        case 'year':
            $query = "SELECT c.name AS category, SUM(sp.amount) AS total_amount 
                      FROM spending_patterns sp
                      JOIN spending_categories c ON sp.category_id = c.id
                      WHERE sp.user_id = ? AND sp.transaction_date >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)
                      GROUP BY c.name";
            break;
    }
    
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $spending_data = [];
    $total_spending = 0;
    while ($row = mysqli_fetch_assoc($result)) {
        $spending_data[] = $row;
        $total_spending += $row['total_amount'];
    }
    
    return [
        'spending_data' => $spending_data,
        'total_spending' => $total_spending
    ];
}

// Handle adding new spending entry
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_spending'])) {

    $user_id = $_SESSION['user_id']; 

    // Detailed category validation
    if (!isset($_POST['category'])) {
        die("ERROR: No category selected. POST data: " . print_r($_POST, true));
    }
    
    $category_id = intval($_POST['category']);

    // Verify category exists in database
    $verify_category_query = "SELECT COUNT(*) as count FROM spending_categories WHERE id = ?";
    $verify_stmt = mysqli_prepare($conn, $verify_category_query);
    mysqli_stmt_bind_param($verify_stmt, "i", $category_id);
    mysqli_stmt_execute($verify_stmt);
    $verify_result = mysqli_stmt_get_result($verify_stmt);
    $category_check = mysqli_fetch_assoc($verify_result);
    
    if ($category_check['count'] == 0) {
        die("ERROR: Invalid category ID. Category ID: " . $category_id);
    }

    //$category_id = isset($_POST['category']) ? intval($_POST['category']) : null;
    $amount = $_POST['amount'];
    $transaction_date = $_POST['transaction_date'];
    $description = isset($_POST['description']) ? $_POST['description'] : '';
    $payment_method = isset($_POST['payment_method']) ? $_POST['payment_method'] : '';
    
    // Validate inputs
    $errors = [];
    if (empty($category_id)) $errors[] = "Category is required";
    if (empty($amount) || $amount <= 0) $errors[] = "Invalid amount";
    if (empty($transaction_date)) $errors[] = "Transaction date is required";
    
    if (empty($errors)) {
        $stmt = mysqli_prepare($conn, "INSERT INTO spending_patterns 
        (user_id, category_id, amount, transaction_date, description, payment_method) 
        VALUES (?, ?, ?, ?, ?, ?)");

        if ($stmt === false) {
            die("Prepare failed: " . mysqli_error($conn));
        }
        // Get the category name from the categories table
        $category_name_query = "SELECT name FROM spending_categories WHERE id = ?";
        $category_name_stmt = mysqli_prepare($conn, $category_name_query);
        mysqli_stmt_bind_param($category_name_stmt, "i", $category_id);
        mysqli_stmt_execute($category_name_stmt);
        $category_name_result = mysqli_stmt_get_result($category_name_stmt);
        $category_name_row = mysqli_fetch_assoc($category_name_result);
        $category_name = $category_name_row['name'];

        // Bind parameters correctly
        mysqli_stmt_bind_param($stmt, "iissss", 
        $user_id, 
        $category_id, 
        $amount, 
        $transaction_date, 
        $description, 
        $payment_method
        );

        if (mysqli_stmt_execute($stmt)) {
            $success_message = "Spending entry added successfully!";
        } else {
            $error_message = "Failed to add spending entry: " . mysqli_error($conn);
        }

        //closing the prepared statement 
        mysqli_stmt_close($stmt); 
    }
}

// Get current period's spending data (default to month)
$current_period_data = getSpendingData($conn, $_SESSION['user_id'], 'month');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Spending Analysis</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- <link rel="stylesheet" href="../assets/css/spending_analysis.css"> -->
    <style>
        <?php include "../assets/css/spending_analysis.css";?>
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar">
        <div class="nav-container">
            <a href="#" class="logo">FinanceFlow</a>
            <div class="nav-links">
                <a href="../view/services.php">Back to Services</a>
                <a href="#">Profile</a>
            </div>
        </div>
    </nav>
    <div class="container">
        <div class="header">
            <h1>Spending Analysis</h1>
            <p>Track, analyze, and optimize your spending habits</p>
        </div>
        
        <!-- Add Spending Button -->
        <button id="addSpendingBtn" class="btn">Add New Spending</button>
        
        <!-- Add Spending Modal -->
        <div id="addSpendingModal" class="modal">
            <div class="modal-content">
                <span class="close-btn" id = "closeModal">&times;</span>
                <h2>Add New Spending Entry</h2>
                <?php 
                if (!empty($errors)) {
                    echo "<div class='error-messages'>";
                    foreach ($errors as $error) {
                        echo "<p>$error</p>";
                    }
                    echo "</div>";
                }
                if (isset($success_message)) {
                    echo "<div class='success-message'>$success_message</div>";
                }
                ?>
                <form method="POST" action="">
                    <input type="hidden" name="add_spending" value="1">
                    <div class="form-group">
                        <label>Category</label>
                        <select name="category" required>
                            <?php foreach ($categories as $category): ?>
                                <option value="<?= $category['id'] ?>"><?= $category['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Amount</label>
                        <input type="number" name="amount" step="0.01" required>
                    </div>
                    <div class="form-group">
                        <label>Transaction Date</label>
                        <input type="date" name="transaction_date" required>
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <input type="text" name="description">
                    </div>
                    <div class="form-group">
                        <label>Payment Method</label>
                        <select name="payment_method">
                            <option value="cash">Cash</option>
                            <option value="credit_card">Credit Card</option>
                            <option value="debit_card">Debit Card</option>
                            <option value="bank_transfer">Bank Transfer</option>
                        </select>
                    </div>
                    <button type="submit" class="btn">Save Spending</button>
                </form>
            </div>
        </div>
        
        <!-- Time Period Filters -->
        <div class="filters">
            <button class="filter-btn active" data-period="month">This Month</button>
            <button class="filter-btn" data-period="quarter">Last 3 Months</button>
            <button class="filter-btn" data-period="halfYear">Last 6 Months</button>
            <button class="filter-btn" data-period="year">Last Year</button>
        </div>
        
        <!-- Charts and Insights -->
        <div class="grid">
            <div class="chart-container">
                <h2>Spending Breakdown</h2>
                <canvas id="spendingChart"></canvas>
                
                <h2>Spending Trend</h2>
                <canvas id="trendChart"></canvas>
                
                <div class="insights">
                    <h2>Spending Insights</h2>
                    <div class="insight-item">
                        <p>Total Spending: $<?= number_format($current_period_data['total_spending'], 2) ?></p>
                        <!-- Add more dynamic insights based on data -->
                    </div>
                </div>
            </div>
        </div>  
    </div>

    <script>
    // PHP to JS data transfer
    const spendingData = <?= json_encode($current_period_data['spending_data']) ?>;
    const totalSpending = <?= $current_period_data['total_spending'] ?>;

    // Chart initialization and filtering logic (similar to previous JS)
    function initializeCharts(data) {
        const ctx = document.getElementById('spendingChart').getContext('2d');
        const trendCtx = document.getElementById('trendChart').getContext('2d');

        // Spending Breakdown Chart
        new Chart(ctx, {
            type: 'pie',
            data: {
                labels: data.map(item => item.category),
                datasets: [{
                    data: data.map(item => item.total_amount),
                    backgroundColor: [
                        '#FF6384', '#36A2EB', '#FFCE56', 
                        '#4BC0C0', '#9966FF', '#FF9F40'
                    ]
                }]
            }
        });

        // Trend Chart (placeholder - you'd need to modify to fetch actual trend data)
        new Chart(trendCtx, {
            type: 'line',
            data: {
                labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
                datasets: [{
                    label: 'Weekly Spending',
                    data: [totalSpending/4, totalSpending/4, totalSpending/4, totalSpending/4],
                    borderColor: '#36A2EB'
                }]
            }
        });
    }

    // Initialize charts on page load
    document.addEventListener('DOMContentLoaded', () => {
        initializeCharts(spendingData);

        // Modal functionality
        const modal = document.getElementById('addSpendingModal');
        const btn = document.getElementById('addSpendingBtn');
        const span = document.getElementsByClassName('close')[0];

        btn.onclick = () => modal.style.display = 'block';
        span.onclick = () => modal.style.display = 'none';
        window.onclick = (event) => {
            if (event.target == modal) modal.style.display = 'none';
        };
    });

    document.getElementById("addSpendingBtn").addEventListener("click", function () {
        document.getElementById("modal").style.display = "block";
    });

    document.getElementById("closeModal").addEventListener("click", function () {
        document.getElementById("modal").style.display = "none";
    });

    window.addEventListener("click", function (event) {
        const modal = document.getElementById("modal");
        if (event.target === modal) {
            modal.style.display = "none";
        }
    });

    </script>
</body>
</html>