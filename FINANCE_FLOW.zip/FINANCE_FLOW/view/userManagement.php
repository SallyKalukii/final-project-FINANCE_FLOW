<?php
require_once '../db/config.php';
session_start();


// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 1 && $_SESSION['role'] != 2)) {
    header("Location: login.php");
    exit();
}

// Function to check if user is super admin
function isSuperAdmin() {
    return $_SESSION['role'] == 1;
}

function userExists($email, $conn, $exclude_user_id = null) {
    $email = mysqli_real_escape_string($conn, $email);
    $sql = "SELECT user_id FROM finance_users WHERE email = '$email'";
    
    // If we're updating a user, exclude their own email from the check
    if ($exclude_user_id) {
        $exclude_user_id = mysqli_real_escape_string($conn, $exclude_user_id);
        $sql .= " AND user_id != '$exclude_user_id'";
    }
    
    $result = mysqli_query($conn, $sql);
    return mysqli_num_rows($result) > 0;
}

// Handle user actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                if (isSuperAdmin() || $_SESSION['role'] == 2) {
                    $fname = mysqli_real_escape_string($conn, $_POST['fname']);
                    $lname = mysqli_real_escape_string($conn, $_POST['lname']);
                    $email = mysqli_real_escape_string($conn, $_POST['email']);
                    
                    // Check if user exists
                    if (userExists($email, $conn)) {
                        echo "<div class='alert alert-danger'>User with this email already exists!</div>";
                    } else {
                        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
                        $role = isSuperAdmin() ? mysqli_real_escape_string($conn, $_POST['role']) : 3;

                        $sql = "INSERT INTO finance_users (fname, lname, email, password, role) 
                                VALUES ('$fname', '$lname', '$email', '$password', '$role')";
                        if(mysqli_query($conn, $sql)) {
                            echo "<div class='alert alert-success'>User added successfully!</div>";
                        } else {
                            echo "<div class='alert alert-danger'>Error adding user: " . mysqli_error($conn) . "</div>";
                        }
                    }
                }
                break;

            case 'edit':
                if (isSuperAdmin() || $_SESSION['role'] == 2) {
                    $user_id = mysqli_real_escape_string($conn, $_POST['user_id']);
                    $fname = mysqli_real_escape_string($conn, $_POST['fname']);
                    $lname = mysqli_real_escape_string($conn, $_POST['lname']);
                    $email = mysqli_real_escape_string($conn, $_POST['email']);
                        
                    // Check if email exists for other users
                    if (userExists($email, $conn, $user_id)) {
                        echo "<div class='alert alert-danger'>Another user with this email already exists!</div>";
                    } else {
                        $sql = "UPDATE finance_users SET 
                                fname = '$fname', 
                                lname = '$lname', 
                                email = '$email'";
                            
                        if (isSuperAdmin() && isset($_POST['role'])) {
                            $role = mysqli_real_escape_string($conn, $_POST['role']);
                            $sql .= ", role = '$role'";
                        }
                            
                        $sql .= " WHERE user_id = '$user_id'";
                        if(mysqli_query($conn, $sql)) {
                            echo "<div class='alert alert-success'>User updated successfully!</div>";
                        } else {
                            echo "<div class='alert alert-danger'>Error updating user: " . mysqli_error($conn) . "</div>";
                        }
                    }
                }
                break;

            case 'delete':
                if (isSuperAdmin()) {
                    $user_id = mysqli_real_escape_string($conn, $_POST['user_id']);
                    $sql = "DELETE FROM finance_users WHERE user_id = '$user_id'";
                    mysqli_query($conn, $sql);
                }
                break;
        }
    }
}

// Fetch all users
$sql = "SELECT * FROM finance_users ORDER BY created_at DESC";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management</title>
    <!-- <link rel="stylesheet" href="../css/userManagement.css"> -->
    <style>
        <?php include "../assets/css/userManagement.css";?>
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <a href="#" class="logo">FinanceFlow</a>
            <div class="nav-links">
                <a href="../view/services.php">Back to Services</a>
            </div>
        </div>
    </nav>
    <div class="container">
        <h1>User Management</h1>
        
        <?php if (isSuperAdmin() || $_SESSION['role'] == 2): ?>
        <div class="add-user-section">
            <h2>Add New User</h2>
            <form method="POST" class="add-user-form">
                <input type="hidden" name="action" value="add">
                <input type="text" name="fname" placeholder="First Name" required>
                <input type="text" name="lname" placeholder="Last Name" required>
                <input type="email" name="email" placeholder="Email" required>
                <input type="password" name="password" placeholder="Password" required>
                <?php if (isSuperAdmin()): ?>
                <select name="role">
                    <option value="2">Admin</option>
                    <option value="3">Regular User</option>
                </select>
                <?php endif; ?>
                <button type="submit">Add User</button>
            </form>
        </div>
        <?php endif; ?>

        <div class="users-list">
            <h2>Users List</h2>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Created At</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['fname'] . ' ' . $row['lname']); ?></td>
                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                        <td><?php echo $row['role'] == 1 ? 'Super Admin' : ($row['role'] == 2 ? 'Admin' : 'User'); ?></td>
                        <td><?php echo date('Y-m-d', strtotime($row['created_at'])); ?></td>
                        <td class="actions">
                            <?php if (isSuperAdmin() || ($_SESSION['role'] == 2 && $row['role'] != 1)): ?>
                            <button onclick="editUser(<?php echo $row['user_id']; ?>)" class="edit-btn">Edit</button>
                            <?php endif; ?>
                            
                            <?php if (isSuperAdmin() && $row['user_id'] != $_SESSION['user_id']): ?>
                            <button onclick="deleteUser(<?php echo $row['user_id']; ?>)" class="delete-btn">Delete</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        // Get the modal
        const modal = document.getElementById("editUserModal");
        const span = document.getElementsByClassName("close")[0];

        // Function to edit user
        function editUser(userId) {
            // Fetch user data using AJAX
            fetch(`get_user.php?user_id=${userId}`)
                .then(response => response.json())
                .then(data => {
                    document.getElementById('edit_user_id').value = data.user_id;
                    document.getElementById('edit_fname').value = data.fname;
                    document.getElementById('edit_lname').value = data.lname;
                    document.getElementById('edit_email').value = data.email;
                    if (document.getElementById('edit_role')) {
                        document.getElementById('edit_role').value = data.role;
                    }
                    modal.style.display = "block";
                })
                .catch(error => console.error('Error:', error));
        }

        // Close modal when clicking the x
        span.onclick = function() {
            modal.style.display = "none";
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }

        // Function to delete user
        function deleteUser(userId) {
            if (confirm('Are you sure you want to delete this user?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="user_id" value="${userId}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }
    </script>
</body>
</html>